import decimal
import requests
import uuid
import json
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    InvalidSessionIdException,
    StaleElementReferenceException
)
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import logging
import time
import os
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv
from decimal import Decimal, getcontext, ROUND_DOWN
from decimal import localcontext
import re

# Diccionario global para almacenar IDs de órdenes detectadas previamente
order_ids = {}

# Declarar la memoria de órdenes abiertas del ciclo anterior
memoria_ordenes = {}  # Clave: (pair, order_type); Valor: detalles de la orden

# Configuración global de decimal
getcontext().prec = 10  # Precisión global (ajústala según tus necesidades)

def redondear_decimal(valor):
    """
    Convierte el valor a Decimal (si no lo es ya) y lo redondea a 4 decimales usando ROUND_DOWN.
    """
    if not isinstance(valor, Decimal):
        valor = Decimal(str(valor))
    with localcontext() as ctx:
        ctx.prec = 28  # Aumenta la precisión local para esta operación
        return valor.quantize(Decimal("0.0001"), rounding=ROUND_DOWN)

# Cargar variables de entorno
load_dotenv()

# ------------------------------------------------
# CONFIGURACIÓN
# ------------------------------------------------

PAIRS_URLS = {
    #"USDT-EUR": "https://exchange.revolut.com/trade/USDT-EUR",
    "USDC-EUR": "https://exchange.revolut.com/trade/USDC-EUR",
    #"USDT-GBP": "https://exchange.revolut.com/trade/USDT-GBP",
    "USDC-GBP": "https://exchange.revolut.com/trade/USDC-GBP",
}

PRICE_FILE = os.path.join(os.path.dirname(__file__), "prices.txt")

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
TELEGRAM_TOKEN2 = os.getenv("TELEGRAM_TOKEN2")
TELEGRAM_CHAT_ID2 = os.getenv("TELEGRAM_CHAT_ID2")

# ------------------------------------------------
# LOGGING
# ------------------------------------------------
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ------------------------------------------------
# VARIABLE GLOBAL PARA EL COSTE BASE (DEPÓSITO)
# ------------------------------------------------
COSTE_BASE = Decimal("10000.0")  # Ahora también es Decimal

# ------------------------------------------------
# INICIAR SELENIUM
# ------------------------------------------------
def iniciar_driver(url_inicial):
    chrome_options = Options()
    chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    driver_version = os.getenv("CHROMEDRIVER_VERSION")
    if driver_version:
        executable_path = ChromeDriverManager(driver_version=driver_version).install()
    else:
        executable_path = ChromeDriverManager().install()
    service = Service(executable_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.get(url_inicial)
    return driver

URL_INICIAL = "https://exchange.revolut.com/trade/USDC-EUR"
driver = iniciar_driver(URL_INICIAL)
logger.info("Bot iniciado.")

# ------------------------------------------------
# FUNCIÓN DE NOTIFICACIONES A TELEGRAM
# ------------------------------------------------
def enviar_notificacion(mensaje: str):
    url_telegram = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {"chat_id": TELEGRAM_CHAT_ID, "text": mensaje}
    try:
        response = requests.post(url_telegram, data=data)
        if response.status_code != 200:
            logger.error(f"Telegram API respondió con código {response.status_code}: {response.text}")
    except Exception as e:
        logger.error(f"Al enviar notificación a Telegram: {e}")

def enviar_notificacion_sec(mensaje: str):
    """
    Envía una notificación al grupo de Telegram secundario usando TELEGRAM_CHAT_ID_SEC.
    """
    url_telegram = f"https://api.telegram.org/bot{TELEGRAM_TOKEN2}/sendMessage"
    data = {"chat_id": TELEGRAM_CHAT_ID2, "text": mensaje}
    try:
        response = requests.post(url_telegram, data=data)
        if response.status_code != 200:
            logger.error(f"Telegram API (secundario) respondió con código {response.status_code}: {response.text}")
    except Exception as e:
        logger.error(f"Al enviar notificación secundaria a Telegram: {e}")

# ------------------------------------------------
# FUNCIÓN PARA OBTENER ÓRDENES ABIERTAS DESDE LA PÁGINA ACTUAL
# ------------------------------------------------
# ------------------------------------------------
# UTILIDADES PARA ESTADO DE ÓRDENES
# ------------------------------------------------
def is_open_status(texto: str) -> bool:
    """
    Devuelve True si el contenido de la columna Status indica que la orden sigue abierta.
    Se considera:
    - 'Open'
    - Un porcentaje, incluso si tiene texto adicional como '56% filled'.
    """
    if not texto:
        return False
    texto = texto.strip().lower()
    if texto == "open":
        return True
    # Buscar un porcentaje al inicio del texto
    match = re.match(r"^(\d+(\.\d+)?)%", texto)
    if match:
        return True
    return False

def parse_all_open_orders(driver):
    """
    Parsea las órdenes abiertas visibles en la vista actual, 
    pero sólo aquellas con Status == "Open".
    Retorna un set() con los pares encontrados.
    """
    pares_con_ordenes = set()
    try:
        wait = WebDriverWait(driver, 30)
        rows = wait.until(EC.presence_of_all_elements_located(
            (By.XPATH, "//div[@data-rui-part='table-scroll-wrapper']//div[@role='row']")
        ))

        for row in rows:
            # Ignorar órdenes canceladas (icono Reverted)
            try:
                row.find_element(By.XPATH, ".//span[contains(@style,'Reverted.svg')]")
                continue
            except NoSuchElementException:
                pass
            # 1) Filtrar por Status: buscar el span con texto (ignorar iconos)
            status_text = ""
            for span in row.find_elements(By.XPATH, ".//div[@aria-colindex='5']//span"):
                txt = span.text.strip()
                if txt:
                    status_text = txt
                    break
            if not is_open_status(status_text):
                continue

            # 2) Extraer celdas y par
            cells = row.find_elements(By.XPATH, ".//div[@role='cell']")
            if not cells:
                continue

            row_pair = cells[0].text.strip()
            if not row_pair or row_pair.lower() == "pair":
                continue

            # Normalizar el par para que coincida con las claves de PAIRS_URLS
            row_pair_norm = row_pair.upper().replace(" ", "-").replace("/", "-")
            pares_con_ordenes.add(row_pair_norm)

    except Exception as e:
        logging.error(f"Error general al obtener la lista de órdenes abiertas: {e}")

    return pares_con_ordenes

# ------------------------------------------------
# TAB MANAGEMENT
# ------------------------------------------------
def ensure_orders_tab():
    """
    Activa la pestaña Orders/Open orders.  Es tolerante a “no hay órdenes abiertas”.
    """
    try:
        wait = WebDriverWait(driver, 5)

        # 1. Localizar el span 'Orders' (inglés) — texto exacto
        try:
            target_span = wait.until(
                EC.presence_of_element_located(
                    (By.XPATH, "//span[normalize-space()='Orders']")
                )
            )
        except TimeoutException:
            # 2. Fallback: 'Open orders' (inglés)
            try:
                target_span = wait.until(
                    EC.presence_of_element_located(
                        (By.XPATH, "//span[normalize-space()='Open orders']")
                    )
                )
            except TimeoutException:
                # 3. Fallback español
                target_span = wait.until(
                    EC.presence_of_element_located(
                        (By.XPATH, "//span[translate(normalize-space(text()),'Óó','Oo')='órdenes']")
                    )
                )

        # Hacer click con JS (el contenedor no siempre es clickable)
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", target_span)
        driver.execute_script("arguments[0].click();", target_span)

        # Intentar verificar visualmente que está seleccionada: la pestaña activa NO tiene cursor:pointer
        # Si aún tiene cursor:pointer, esperar brevemente y volver a hacer click.
        try:
            if "pointer" in (target_span.get_attribute("style") or ""):
                time.sleep(0.2)
                driver.execute_script("arguments[0].click();", target_span)
        except Exception:
            pass  # no crítico

        # No fallar si no hay órdenes abiertas; simplemente esperar medio segundo
        time.sleep(0.5)
    except Exception as e:
        logger.error(f"ensure_orders_tab(): no se pudo activar pestaña Orders – {e}")

# ------------------------------------------------
# FUNCIONES AUXILIARES DE PRECIOS
# ------------------------------------------------
def obtener_precio_actual(pair: str) -> Decimal:
    """
    Obtiene el precio actual para distintos pares.
    - USDT-EUR y USDC-EUR: inversa (basado en la API de Binance).
    - USDT-GBP y USDC-GBP: precio directo en Kraken.
    Devuelve un Decimal redondeado a 4 decimales.
    """
    try:
        if pair.upper().replace(" ", "-") == "USDT-EUR":
            response = requests.get("https://api.binance.com/api/v3/ticker/price?symbol=EURUSDT")
            response.raise_for_status()
            precio = Decimal(str(response.json()['price']))
            inversa = Decimal('1') / precio if precio != Decimal('0') else Decimal('0')
            return redondear_decimal(inversa)
        
        elif pair.upper().replace(" ", "-") == "USDC-EUR":
            res_usdc = requests.get("https://api.binance.com/api/v3/ticker/price?symbol=USDCUSDT")
            res_eur = requests.get("https://api.binance.com/api/v3/ticker/price?symbol=EURUSDT")
            res_usdc.raise_for_status()
            res_eur.raise_for_status()
            usdc_usdt = Decimal(str(res_usdc.json()['price']))
            eur_usdt = Decimal(str(res_eur.json()['price']))
            inversa = (usdc_usdt / eur_usdt) if eur_usdt != Decimal('0') else Decimal('0')
            return redondear_decimal(inversa)

        elif pair.upper().replace(" ", "-") == "USDT-GBP":
            response = requests.get("https://api.kraken.com/0/public/Ticker?pair=USDTGBP")
            response.raise_for_status()
            data = response.json()
            if 'result' not in data:
                raise ValueError("La respuesta de Kraken no contiene la clave 'result'.")
            result_key = list(data['result'].keys())[0]
            price = Decimal(str(data['result'][result_key]['c'][0]))
            return redondear_decimal(price)

        elif pair.upper().replace(" ", "-") == "USDC-GBP":
            response = requests.get("https://api.kraken.com/0/public/Ticker?pair=USDCGBP")
            response.raise_for_status()
            data = response.json()
            if 'result' not in data:
                raise ValueError("La respuesta de Kraken no contiene la clave 'result'.")
            result_key = list(data['result'].keys())[0]
            price = Decimal(str(data['result'][result_key]['c'][0]))
            return redondear_decimal(price)

        else:
            logger.error(f"Par no soportado: {pair}")
            return Decimal('0')
    
    except Exception as e:
        logger.error(f"Error al obtener precio para {pair}: {e}")
        return Decimal('0')

def actualizar_inverse_price(pair: str, inversa: Decimal):
    """
    Guarda TODOS los precios en un archivo (prices.txt) como JSON.
    Estructura: { "USDT-EUR": 1.2345, ... }
    """
    try:
        # Leer datos existentes (si los hay)
        try:
            with open(PRICE_FILE, "r") as f:
                prices = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            prices = {}

        # Actualizar el par actual; convertir a string para serializar Decimal
        prices[pair] = format(inversa, ".4f")

        # Guardar
        with open(PRICE_FILE, "w") as f:
            json.dump(prices, f, indent=4)
            
    except Exception as e:
        logger.error(f"Error guardando precios: {e}")

# ------------------------------------------------
# FUNCIONES PARA ÓRDENES
# ------------------------------------------------
def parse_my_open_orders(current_pair: str):
    # Asegurarse de estar en la pestaña correcta antes de parsear
    ensure_orders_tab()
    # Esperar explícitamente a que carguen filas con Status abierto
    try:
        WebDriverWait(driver, 5).until(
            lambda d: any(
                is_open_status(el.text)
                for el in d.find_elements(By.XPATH, "//div[@aria-colindex='5']//span")
            )
        )
    except TimeoutException:
        logger.warning("No se detectaron filas 'Open' tras cambiar a la pestaña Orders.")
    orders = []
    try:
        # Localizar el contenedor de la tabla de órdenes y sus filas
        table_wrapper = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@data-rui-part='table-scroll-wrapper']"))
        )
        rows = table_wrapper.find_elements(By.XPATH, ".//div[@role='row']")

        for row in rows:
            # Ignorar órdenes canceladas (icono Reverted)
            try:
                row.find_element(By.XPATH, ".//span[contains(@style,'Reverted.svg')]")
                continue
            except NoSuchElementException:
                pass
            # Analizar el estado / porcentaje ejecutado: ignorar iconos
            status_text = ""
            for span in row.find_elements(By.XPATH, ".//div[@aria-colindex='5']//span"):
                txt = span.text.strip()
                if txt:
                    status_text = txt
                    break
            if not status_text:
                continue

            if status_text.lower() == "open":
                porcentaje = 0.0
            else:
                # Detectar porcentaje en cualquier posición (por ejemplo '56% filled')
                pct_match = re.search(r"(\d+(\.\d+)?)%", status_text)
                if pct_match:
                    porcentaje = float(pct_match.group(1))
                else:
                    continue
            try:
                cells = row.find_elements(By.XPATH, ".//div[@role='cell']")
                total_cells = len(cells)
                if total_cells < 6:
                    continue
                # Par
                row_pair = cells[0].text.strip()
                if not row_pair or row_pair.lower() == "pair":
                    continue
                row_pair_norm = row_pair.upper().replace(" ", "-").replace("/", "-")
                current_norm = current_pair.upper().replace(" ", "-").replace("/", "-")
                if row_pair_norm != current_norm:
                    continue

                # Tipo Buy/Sell  (colindex 3)
                try:
                    tipo_text = row.find_element(By.XPATH, ".//div[@aria-colindex='3']//span").text.strip()
                except Exception:
                    continue
                if tipo_text not in ["Buy", "Sell"]:
                    continue

                # --------------------------------------------
                # Columnas numéricas (estructura UI mayo‑2025)
                # colindex 6 => amount (USDC), 7 => limit price (€), 8 => total value (€)
                # --------------------------------------------
                try:
                    raw_price_text = row.find_element(By.XPATH, ".//div[@aria-colindex='7']//span").text.strip()
                    cleaned_price = limpiar_valor(raw_price_text)
                    order_price = redondear_decimal(Decimal(cleaned_price)) if cleaned_price else Decimal("0")
                except Exception:
                    order_price = Decimal("0")

                try:
                    raw_value_text = row.find_element(By.XPATH, ".//div[@aria-colindex='8']//span").text.strip()
                    cleaned_value = limpiar_valor(raw_value_text)
                    if not cleaned_value:
                        logger.warning(f"Valor EUR no válido '{raw_value_text}' al parsear {current_pair}")
                        continue
                    order_eur = float(cleaned_value)
                except Exception:
                    logger.warning(f"No se pudo extraer valor EUR al parsear {current_pair}")
                    continue

                # Asignar un identificador único persistente
                global order_ids
                key_id = (current_pair, tipo_text)  # Asumimos una única orden por par y tipo
                if key_id in order_ids:
                    order_uuid = order_ids[key_id]
                else:
                    order_uuid = str(uuid.uuid4())
                    order_ids[key_id] = order_uuid

                orders.append({
                    "id": order_uuid,
                    "type": tipo_text,
                    "price": order_price,
                    "eur_value": order_eur,
                    "percentage": porcentaje,
                    "element": row
                })

            except Exception as e:
                logger.error(f"ERROR en fila al parsear {current_pair}: {str(e)}")
                continue

        return orders

    except TimeoutException:
        logger.error(f"Timeout esperando filas de órdenes para {current_pair}.")
        return []
    except Exception as e:
        logger.error(f"Error al leer órdenes de {current_pair}: {e}")
        return []

def cancelar_orden(order_row):
    max_attempts = 5
    for attempt in range(max_attempts):
        try:
            # Extraer el par y normalizarlo
            pair_cell = order_row.find_element(By.XPATH, './/div[@aria-colindex="1"]')
            order_pair = pair_cell.text.strip()
            order_pair_norm = order_pair.upper().replace(" ", "-")
            expected_url = PAIRS_URLS.get(order_pair_norm)
            if not expected_url:
                logger.error(f"No se encontró URL para el par {order_pair_norm}.")
                return False

            # No se verifica ni se navega a la URL esperada; se utiliza la URL actual directamente
            # Asegurar que la pestaña Orders esté activa para que exista el botón de cancelación
            ensure_orders_tab()

            # Verificar que la fila siga en estado Open; si no, terminar temprano
            status_text = ""
            for span in order_row.find_elements(By.XPATH, './/div[@aria-colindex="5"]//span'):
                txt = span.text.strip()
                if txt:
                    status_text = txt
                    break
            if not is_open_status(status_text):
                logger.info(f"Orden {order_pair_norm} ya no está abierta (status='{status_text}'); se omite cancelación.")
                return False

            # Continuar con el proceso de cancelación
            order_type_element = order_row.find_element(
                By.XPATH, './/div[@aria-colindex="3"]//span[text()="Buy" or text()="Sell"]'
            )
            order_type = order_type_element.text.strip()
            # En la nueva UI el precio límite está en aria-colindex='7'
            precio_cell = order_row.find_element(By.XPATH, './/div[@aria-colindex="7"]//span')
            raw_price_text = precio_cell.text.strip()
            cleaned_price = limpiar_valor(raw_price_text)
            if cleaned_price:
                order_price = redondear_decimal(Decimal(cleaned_price))
            else:
                logger.warning(f"Precio no válido '{raw_price_text}' al cancelar orden en {order_pair_norm}")
                order_price = Decimal("0")
            
            logger.info(
                f"Intento {attempt+1}/{max_attempts} - Cancelando orden {order_type} en {order_pair_norm} a precio {order_price:.4f} "
                f"usando la URL actual: {driver.current_url}"
            )
            
            driver.execute_script("arguments[0].scrollIntoView(true);", order_row)
            time.sleep(0.5)
            # Localizar el botón (icono “×”) para cancelar la orden.
            try:
                cancel_button = order_row.find_element(By.CSS_SELECTOR, '[aria-label="Cancel order"]')
            except (NoSuchElementException, StaleElementReferenceException):
                # Si no hay botón, la orden probablemente ya no es cancelable
                logger.info(f"No se encontró botón 'Cancel order' en fila {order_pair_norm}; puede que ya esté cerrada.")
                return False
            # Esperar explícitamente a que el botón sea interactuable
            wait = WebDriverWait(driver, 5)
            wait.until(lambda d: cancel_button.is_displayed() and cancel_button.is_enabled())
            driver.execute_script("arguments[0].scrollIntoView(true);", cancel_button)
            time.sleep(0.3)
            driver.execute_script("arguments[0].click();", cancel_button)
            time.sleep(1)
            
            logger.info("Orden cancelada exitosamente en intento " + str(attempt+1))
            return True
        except Exception as e:
            logger.error(f"Error en intento {attempt+1} al cancelar orden: {e}")
            time.sleep(1)
    return False

# ------------------------------------------------
# LEER TOP BUY
# ------------------------------------------------
def obtener_top_buy() -> Decimal:
    """
    Obtiene el precio top de Buy (el más alto).
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Seleccionar el contenedor principal del libro de órdenes
        buy_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.cssFiH")
            )
        )
        # Encontrar todas las filas del contenedor
        rows = buy_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        if rows:
            first_row = rows[0]  # La primera fila contiene el precio top de compra
            # Buscar el primer span que contiene el precio
            price_span = first_row.find_element(By.CSS_SELECTOR, "span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0.cycWlz.drfGDu")
            if price_span:
                raw_price = price_span.text.strip().replace(",", ".")
                if raw_price and raw_price.lower() != "price":
                    try:
                        top_buy = Decimal(raw_price)
                        return redondear_decimal(top_buy)
                    except Exception as e:
                        logger.error(f"Error al convertir el precio top buy: {e}")
                        return Decimal('0')
                logger.info("No se encontró un valor de precio válido en el Top Buy.")
                return Decimal('0')
        logger.info("No se encontraron filas para determinar el Top Buy.")
        return Decimal('0')
    except Exception as e:
        logger.error(f"No se pudo obtener el Top Buy: {e}")
        return Decimal('0')

# ------------------------------------------------
# LEER SEGUNDO TOP BUY
# ------------------------------------------------
def obtener_second_top_buy() -> Decimal:
    """
    Obtiene el segundo precio top de Buy (el segundo más alto).
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Actualizado el selector para el contenedor de Buy
        buy_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.cssFiH")
            )
        )
        # Actualizado el selector para las filas
        rows = buy_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        buy_prices = []
        for row in rows:
            try:
                # Actualizado el selector para el elemento de precio
                price_element = row.find_element(By.CSS_SELECTOR, 'span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0.cycWlz.drfGDu')
                raw_price = price_element.text.strip().replace("€", "").replace(",", ".")
                if raw_price and raw_price.lower() != "price":
                    price = Decimal(raw_price)
                    buy_prices.append(price)
            except NoSuchElementException:
                logger.warning("No se encontró el elemento <span> de precio en una fila de Buy.")
                continue
            except Exception as e:
                logger.error(f"Error al extraer el precio en una fila de Buy: {e}")
                continue

        if len(buy_prices) >= 2:
            buy_prices_sorted = sorted(buy_prices, reverse=True)
            second_top_buy = buy_prices_sorted[1]
            return redondear_decimal(second_top_buy)
        else:
            logger.info("No hay suficientes precios de Buy para determinar el segundo Top Buy.")
            return Decimal('0')

    except Exception as e:
        logger.error(f"No se pudo obtener el segundo Top Buy: {e}")
        return Decimal('0')
    
# ------------------------------------------------
# LEER BOTTOM SELL
# ------------------------------------------------
def obtener_bottom_sell() -> Decimal:
    """
    Obtiene el precio bottom de Sell (el más bajo).
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Actualizado el selector para el contenedor de Sell
        sell_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.OrderBookList__StyledBox-sc-awjs02-0")
            )
        )
        # Actualizado el selector para las filas
        rows = sell_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        if not rows:
            logger.info("No hay filas en el contenedor de Sell.")
            return Decimal('0')

        last_row = rows[-1]
        # Actualizado el selector para el elemento de precio (ahora más específico)
        price_element = last_row.find_element(By.CSS_SELECTOR, 'span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0.fxOsBb.drfGDu')
        raw_price = price_element.text.strip().replace("€", "").replace(",", ".")
        
        if raw_price and raw_price.lower() != "price":
            try:
                bottom_sell = Decimal(raw_price)
                return redondear_decimal(bottom_sell)
            except Exception as e:
                logger.error(f"Error al convertir precio Bottom Sell: {e}")
                return Decimal('0')
        else:
            logger.warning("El texto de precio Bottom Sell no es válido.")
            return Decimal('0')

    except NoSuchElementException:
        logger.error("No se encontró el elemento de precio en Bottom Sell.")
        return Decimal('0')
    except Exception as e:
        logger.error(f"No se pudo obtener el Bottom Sell: {e}")
        return Decimal('0')

# ------------------------------------------------
# LEER SEGUNDO BOTTOM SELL
# ------------------------------------------------
def obtener_second_bottom_sell() -> Decimal:
    """
    Obtiene el segundo precio bottom de Sell (el segundo más bajo).
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Selector actualizado para el contenedor de Sell en la nueva UI
        sell_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.OrderBookList__StyledBox-sc-awjs02-0")
            )
        )
        # Obtener todas las filas del contenedor
        rows = sell_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        sell_prices = []
        for row in rows:
            try:
                # Apuntar específicamente al span de precio
                price_span = row.find_element(By.CSS_SELECTOR, 'span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0.fxOsBb.drfGDu')
                raw_price = price_span.text.strip().replace("€", "").replace(",", ".")
                if raw_price and raw_price.lower() != "price":
                    price = Decimal(raw_price)
                    sell_prices.append(price)
            except Exception as e:
                continue

        # Ordenar precios en orden ascendente
        sell_prices = sorted(sell_prices)
        if len(sell_prices) >= 2:
            second_bottom_sell = sell_prices[1]
            return redondear_decimal(second_bottom_sell)
        else:
            logger.info("No hay suficientes precios de Sell para determinar el segundo Bottom Sell.")
            return Decimal('0')

    except Exception as e:
        logger.error(f"No se pudo obtener el segundo Bottom Sell: {e}")
        return Decimal('0')

# ------------------------------------------------
# OBTENER Y CALCULAR VALOR DE PORTFOLIO
# ------------------------------------------------
def obtener_valor_portfolio(driver) -> Decimal:
    """
    Simplifica la lógica para leer el valor del portfolio:
    1) Hace click en el botón "Home" y espera que el contenedor del portfolio cargue con un texto.
    2) Extrae el texto del contenedor mediante JavaScript y busca el primer número.
    3) Si no se encuentra un valor numérico, recarga la página y reintenta hasta 5 veces.
    4) Finalmente hace click en "Trade" para volver a la página de trading y retorna el valor (o Decimal('0') si falla).
    """
    max_attempts = 5
    attempt = 0
    wait = WebDriverWait(driver, 5)
    script = """
        function getAllText(element) {
            let text = '';
            for (let node of element.childNodes) {
                if (node.nodeType === 3) {
                    text += node.textContent;
                } else if (node.nodeType === 1) {
                    text += getAllText(node);
                }
            }
            return text;
        }
        return getAllText(arguments[0]);
    """
    while attempt < max_attempts:
        try:
            # Hacer click en el botón "Home"
            home_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'welcome-journey-home') and @href='/home']"))
            )
            home_button.click()

            # Esperar a que el contenedor del portfolio tenga texto
            total_container = wait.until(
                lambda d: d.find_element(By.CSS_SELECTOR, "span.TotalValueMetrics__StableVStack-sc-j27w3u-0")
                if d.find_element(By.CSS_SELECTOR, "span.TotalValueMetrics__StableVStack-sc-j27w3u-0").text.strip() != "" else False
            )

            # Extraer el texto usando JavaScript y buscar un número
            raw_text = driver.execute_script(script, total_container)
            logger.info(f"Texto extraído del portfolio: '{raw_text}'")
            match = re.search(r'(\d+[.,]?\d*)', raw_text)
            if not match:
                raise Exception("No se encontró valor numérico")

            numeric_text = match.group(1)
            logger.info(f"Valor numérico encontrado: '{numeric_text}'")

            # Normalizar el número
            if ',' in numeric_text and '.' in numeric_text:
                if numeric_text.index(',') < numeric_text.index('.'):
                    numeric_text = numeric_text.replace(',', '')
                else:
                    numeric_text = numeric_text.replace('.', '').replace(',', '.')
            elif ',' in numeric_text:
                parts = numeric_text.split(',')
                if len(parts) == 2 and len(parts[1]) <= 2:
                    numeric_text = numeric_text.replace(',', '.')
                else:
                    numeric_text = numeric_text.replace(',', '')

            valor_decimal = Decimal(numeric_text)
            
            # Volver a la página de trading haciendo click en el botón "Trade"
            trade_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'welcome-journey-trade') and @href='/trade']"))
            )
            trade_button.click()
            wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            return valor_decimal

        except Exception as e:
            attempt += 1
            logger.error(f"Intento {attempt}/{max_attempts} fallido al obtener el portfolio: {e}")
            driver.get("https://exchange.revolut.com/home")
            time.sleep(2)

    # Si después de 5 intentos no se pudo extraer el valor, salir del flujo
    trade_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'welcome-journey-trade') and @href='/trade']"))
    )
    trade_button.click()
    wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
    return Decimal('0')

def calcular_ganancia_portfolio(driver) -> Decimal:
    """
    Llama a 'obtener_valor_portfolio' y calcula la ganancia actual:
    total_portfolio - COSTE_BASE.
    Se almacena en 'ganancia.txt'.
    """
    total_portfolio = obtener_valor_portfolio(driver)
    ganancia = total_portfolio - COSTE_BASE

    try:
        with open("ganancia.txt", "w") as f:
            f.write(f"{redondear_decimal(ganancia):.4f}")
    except Exception as e:
        logger.error(f"No se pudo escribir en ganancia.txt: {e}")

    return ganancia

def reposicionar_orden(order_type, reference_price: Decimal, pair, orden_pendiente=None):
    try:
        # Normalizar el par y obtener la URL correspondiente
        pair_norm = pair.upper().replace(" ", "-")
        target_url = PAIRS_URLS.get(pair_norm)
        if not target_url:
            logger.error(f"No se encontró URL para el par {pair_norm}.")
            return False

        if driver.current_url != target_url:
            logger.info(f"[Reposicionar] No estamos en la página correcta para {pair_norm}. Navegando a {target_url}.")
            driver.get(target_url)
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
            )
            time.sleep(1)

            #Decidir el precio según el origen de la orden
        if (orden_pendiente and 
            orden_pendiente.get("origen") == "caso_2" and 
            "nuevo_precio" in orden_pendiente):
            nuevo_precio = Decimal(str(orden_pendiente["nuevo_precio"]))
            logger.info(f"Usando precio precalculado del Caso 2: {nuevo_precio:.4f}")
        else:
            # Calcular nuevo_precio según la lógica del "Caso 2"
            if order_type == "Buy":
                # Usar el valor de referencia (top_buy) que se espera venir en reference_price
                competitor_price = reference_price
                competitor_value = obtener_valor_top_buy()
                second_top = obtener_second_top_buy()
                # Calcular diferencia basado en second_top
                diferencia = competitor_price - second_top if second_top > 0 else Decimal("0")
                if diferencia > Decimal("0"):
                    increments = (diferencia / Decimal("0.0001")).to_integral_value(rounding=ROUND_DOWN)
                    threshold = increments * Decimal("500")
                    if competitor_value > threshold:
                        nuevo_precio = redondear_decimal(competitor_price + Decimal("0.0001"))
                    else:
                        if second_top > 0 and (competitor_price - second_top) >= Decimal("0.0002"):
                            nuevo_precio = redondear_decimal(second_top + Decimal("0.0001"))
                        else:
                            nuevo_precio = redondear_decimal(competitor_price + Decimal("0.0001"))
                else:
                    nuevo_precio = redondear_decimal(competitor_price + Decimal("0.0001"))
            elif order_type == "Sell":
                bottom_sell_val = obtener_bottom_sell()
                competitor_value = obtener_valor_bottom_sell()
                second_bottom = obtener_second_bottom_sell()
                diferencia = second_bottom - bottom_sell_val if second_bottom > 0 else Decimal("0")
                if diferencia > Decimal("0"):
                    increments = (diferencia / Decimal("0.0001")).to_integral_value(rounding=ROUND_DOWN)
                    threshold = increments * Decimal("500")
                    if competitor_value > threshold:
                        nuevo_precio = redondear_decimal(bottom_sell_val - Decimal("0.0001"))
                    else:
                        # Si el valor no justifica estar debajo del bottom_sell, considerar second_bottom
                        if second_bottom > 0 and (second_bottom - bottom_sell_val) >= Decimal("0.0002"):
                            nuevo_precio = redondear_decimal(second_bottom - Decimal("0.0001"))
                        else:
                            nuevo_precio = redondear_decimal(bottom_sell_val - Decimal("0.0001"))
                else:
                    nuevo_precio = redondear_decimal(bottom_sell_val - Decimal("0.0001"))
            else:
                logger.error("Tipo de orden desconocido.")
                return False

        # Obtener precios y valores actuales
        top_buy = obtener_top_buy()
        second_top_buy = obtener_second_top_buy()
        bottom_sell = obtener_bottom_sell()
        second_bottom_sell = obtener_second_bottom_sell()
        current_price = obtener_precio_actual(pair)

        # Para Buy y Sell, si ya existe una orden del mismo tipo en este par, no reposiciona
        existing_orders = parse_my_open_orders(pair)
        # Si se detectan duplicados del mismo tipo, cancelar los sobrantes antes de continuar
        duplicates = [o for o in existing_orders if o["type"] == order_type]
        if len(duplicates) > 1:
            logger.warning(f"Se detectaron {len(duplicates)} órdenes {order_type} duplicadas en {pair}. Intentando cancelar sobrantes.")
            # Mantener la más antigua (primer elemento) y cancelar el resto
            for dup in duplicates[1:]:
                cancelar_orden(dup["element"])
            # Releer órdenes tras la cancelación
            existing_orders = parse_my_open_orders(pair)
        if order_type == "Buy" and any(o["type"] == "Buy" for o in existing_orders):
            logger.info(f"[Reposicionar] Ya existe una orden {order_type} abierta para {pair}, no se reposiciona.")
            return True
        if order_type == "Sell" and any(o["type"] == "Sell" for o in existing_orders):
            logger.info(f"[Reposicionar] Ya existe una orden Sell en {pair}.")
            return True

        # Verificar que el precio actual permita reposicionar según el tipo de orden
        if order_type == "Buy":
            if current_price <= nuevo_precio:
                logger.warning(f"[Reposicionar] No se puede reposicionar Buy a {nuevo_precio:.4f} - Precio actual: {current_price:.4f}.")
                return False
        elif order_type == "Sell":
            if current_price >= (nuevo_precio + Decimal('0.0005')):
                logger.warning(f"[Reposicionar] No se puede reposicionar Sell a {nuevo_precio:.4f} - Precio actual: {current_price:.4f}.")
                return False

        # Configurar la pestaña y el modo Limit
        tab = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, f"//div[@role='tablist']//button[@aria-label='{order_type}']"))
        )
        tab.click()
        order_type_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Order type']"))
        )
        if "Limit" not in order_type_button.text:
            order_type_button.click()
            limit_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable(
                    (By.XPATH, "//button[contains(@id, '-option-LIMIT') and .//span[text()='Limit']]")
                )
            )
            limit_button.click()

        price_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@aria-label='Price']"))
        )
        price_input.click()
        driver.execute_script("arguments[0].value = '';", price_input)
        try:
            price_input.send_keys(f"{nuevo_precio:.4f}")
        except Exception as e:
            logger.warning(f"Fallo al enviar teclas: {e}. Se intentará vía JavaScript.")
            script = (
                "arguments[0].value = arguments[1];"
                "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));"
            )
            driver.execute_script(script, price_input, f"{nuevo_precio:.4f}")

        # Lógica específica según el tipo de orden
        if order_type == "Buy":
            # Usar el slider para ajustar a 100% (arrastrar thumb al 100%)
            slider = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='range'][aria-label='Maximum']"))
            )
            # Arrastrar thumb al 100%
            container = slider.find_element(By.XPATH, "..")
            thumb = container.find_element(By.CSS_SELECTOR, "div.Thumb__Outer-rui__sc-1ahlno4-1")
            width = slider.size['width']
            ActionChains(driver).drag_and_drop_by_offset(thumb, width, 0).perform()
            logger.info(f"[Reposicionar] Slider reposicionado al 100% para orden Buy en {pair}.")
            monto = obtener_monto_orden_input("Buy")
            if monto < Decimal("3"):
                logger.info(f"[Reposicionar] Fondos insuficientes para orden Buy en {pair} (monto: {monto:.2f} < 3).")
                if orden_pendiente is not None:
                    orden_pendiente["status"] = "insufficient_funds"
                return "insufficient_funds"

        elif order_type == "Sell":
            # Usar el slider para ajustar a 100% (arrastrar thumb al 100%)
            slider = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='range'][aria-label='Maximum']"))
            )
            # Arrastrar thumb al 100%
            container = slider.find_element(By.XPATH, "..")
            thumb = container.find_element(By.CSS_SELECTOR, "div.Thumb__Outer-rui__sc-1ahlno4-1")
            width = slider.size['width']
            ActionChains(driver).drag_and_drop_by_offset(thumb, width, 0).perform()
            time.sleep(0.5)
            monto_total = obtener_monto_orden_input("Sell")
            logger.info(f"[Reposicionar] Monto total obtenido (Sell 100%): {monto_total:.2f}")

            # Si no hay fondos suficientes, terminar aquí sin continuar con más lógica
            if monto_total < Decimal("3"):
                logger.info(f"[Reposicionar] Fondos insuficientes detectados en 100% (monto: {monto_total:.2f} < 3). No se intentará 50%.")
                if orden_pendiente is not None:
                    orden_pendiente["status"] = "insufficient_funds"
                return "insufficient_funds"

            # Comprobar si existe otra orden Sell en algún par
            sell_orders = []
            for par in PAIRS_URLS.keys():
                if par != pair:  # Solo consideramos el otro par
                    orders = parse_my_open_orders(par)
                    for o in orders:
                        if o["type"] == "Sell":
                            sell_orders.append(o)

            if not sell_orders:
                # Si no hay ninguna orden Sell abierta, se ajusta el slider a 50%
                slider = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='range'][aria-label='Maximum']"))
                )
                # Arrastrar thumb al 50% (mover hacia la izquierda)
                container = slider.find_element(By.XPATH, "..")
                thumb = container.find_element(By.CSS_SELECTOR, "div.Thumb__Outer-rui__sc-1ahlno4-1")
                width = slider.size['width']
                x_offset = -int(width * 0.5)
                ActionChains(driver).drag_and_drop_by_offset(thumb, x_offset, 0).perform()
                logger.info(f"[Reposicionar] Slider reposicionado al 50% para orden Sell en {pair}.")
            else:
                other_sell = sell_orders[0]
                try:
                    other_value = Decimal(str(other_sell["eur_value"]))
                except Exception:
                    other_value = Decimal("0")
                total_capital = monto_total + other_value
                ideal = total_capital / 2
                tolerance = ideal * Decimal("0.15")
                lower_bound = ideal - tolerance
                upper_bound = ideal + tolerance
                logger.info(f"[Reposicionar] Distribución Sell: Monto actual = {monto_total:.2f}, Otra orden = {other_value:.2f}, Total = {total_capital:.2f}, Ideal = {ideal:.2f} (Rango: {lower_bound:.2f} - {upper_bound:.2f})")

                if lower_bound <= monto_total <= upper_bound:
                    logger.info("[Reposicionar] Distribución 50/50 (±15%) verificada; se procede a colocar la orden Sell con 100%.")
                else:
                    if cancelar_orden(other_sell["element"]):
                        agregar_orden_pendiente("Sell", pair, obtener_bottom_sell)
                        enviar_notificacion(f"❕ {pair} - Orden Sell cancelada por distribución incorrecta.")
                        logger.info("[Reposicionar] Otra orden Sell cancelada por distribución incorrecta; añadida a pendientes.")
                    else:
                        logger.error("[Reposicionar] Error al cancelar la otra orden Sell para ajustar distribución.")
                    return "distribution_not_ok"

            monto_final = obtener_monto_orden_input("Sell")
            if monto_final < Decimal("3"):
                logger.info(f"[Reposicionar] Fondos insuficientes para orden Sell en {pair} (monto: {monto_final:.2f} < 3).")
                if orden_pendiente is not None:
                    orden_pendiente["status"] = "insufficient_funds"
                return "insufficient_funds"

        # Establecer modo Post-Only si es necesario
        execution_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Execution']"))
        )
        if "Post-Only" not in execution_button.text:
            execution_button.click()
            post_only_option = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable(
                    (By.XPATH, "//button[@role='option' and .//span[contains(text(),'Post-Only')]]")
                )
            )
            post_only_option.click()

        # Enviar la orden
        submit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, f"//button[@aria-label='Submit order' and .//span[contains(text(), '{order_type}')]]")
            )
        )
        submit_button.click()
        logger.info(f"[Reposicionar] Orden {order_type} reposicionada a {nuevo_precio:.4f} en {pair}.")
        return True

    except Exception as e:
        logger.error(f"Error en reposicionamiento: {e}")
        return False

ordenes_pendientes = []  # Lista global para almacenar las órdenes pendientes

# Conjunto para almacenar las órdenes canceladas intencionalmente para reposicionamiento.
# Cada entrada es una tupla: (pair, order_type, float(order_price))
orders_cancelled_for_repositioning = set()

def agregar_orden_pendiente(order_type, pair, reference_fn, nuevo_precio=None, origen="otro"):
    """
    Agrega una orden pendiente con un identificador único.
    """
    # Evitar añadir pendientes si ya existe una orden abierta o pendiente del mismo par y tipo
    pair_norm = pair.upper().replace(" ", "-")
    open_orders_same = [o for o in parse_my_open_orders(pair) if o["type"] == order_type]
    pending_same = [(p["pair"], p["order_type"]) for p in ordenes_pendientes]
    if open_orders_same or (pair_norm, order_type) in pending_same:
        logger.info(f"Se ignoró agregar pendiente {order_type}-{pair_norm}: ya existe abierta o pendiente.")
        return

    pendiente = {
        "id": str(uuid.uuid4()),   # Identificador único
        "order_type": order_type,
        "pair": pair_norm,
        "reference_fn": reference_fn,
        "timestamp": time.time(),
        "status": "pending",
        "nuevo_precio": nuevo_precio,
        "origen": origen  # Indica si es del Caso 2 o no
    }

    if origen == "caso_2" and nuevo_precio is not None:
        pendiente["nuevo_precio"] = nuevo_precio

    ordenes_pendientes.append(pendiente)
    logger.info(f"Orden pendiente agregada: {pendiente}")

def remove_pending_order(pendiente):
    """
    Elimina de forma segura la orden pendiente identificada por su 'id'.
    """
    global ordenes_pendientes
    ordenes_pendientes[:] = [p for p in ordenes_pendientes if p["id"] != pendiente["id"]]
    logger.info(f"Orden pendiente eliminada: {pendiente['id']}")

def procesar_ordenes_pendientes():
    global ordenes_pendientes
    # Si hay pendiente Sell por fondos insuficientes, cancelar Sell abierta en otros pares y crear pendientes para reposicionar 50/50
    insuf_pends = [p for p in ordenes_pendientes if p["order_type"] == "Sell" and p.get("status") == "insufficient_funds"]
    for pend in insuf_pends:
        for other_pair in PAIRS_URLS.keys():
            if other_pair != pend["pair"]:
                open_orders_other = parse_my_open_orders(other_pair)
                for o in open_orders_other:
                    if o["type"] == "Sell":
                        if cancelar_orden(o["element"]):
                            enviar_notificacion(f"❕ {other_pair} - Orden Sell cancelada para distribuir fondos con {pend['pair']}")
                            # Crear orden pendiente para este par también
                            agregar_orden_pendiente("Sell", other_pair, obtener_bottom_sell)
        # Resetear estado para reintentar la pendient  
        pend["status"] = "pending"
    pendientes_por_par = {}
    for pendiente in ordenes_pendientes.copy():
        par = pendiente["pair"]
        pendientes_por_par.setdefault(par, []).append(pendiente)
    
    for pair, pendientes in pendientes_por_par.items():
        target_url = PAIRS_URLS.get(pair)
        if driver.current_url != target_url:
            driver.get(target_url)
            try:
                WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
                )
            except Exception as e:
                logger.error(f"Error esperando elementos en {pair}: {e}")
            time.sleep(2)
        
        for pendiente in pendientes.copy():
            if pendiente.get("status") != "pending":
                logger.info(f"[Pendiente] Orden {pendiente['order_type']} en {pendiente['pair']} ignorada por estado '{pendiente['status']}'.")
                continue
            order_type = pendiente["order_type"]
            open_orders = parse_my_open_orders(pair)
            # Filtrar las órdenes abiertas que ya fueron canceladas intencionalmente para reposicionamiento.
            open_orders = [o for o in open_orders if (pair, o["type"], o["id"]) not in orders_cancelled_for_repositioning]
            
            # NUEVO BLOQUE: Si hay órdenes abiertas del mismo tipo, cancelarlas para poder reposicionarlas
            open_orders_same = [o for o in open_orders if o["type"] == order_type]
            if open_orders_same:
                for o in open_orders_same:
                    if cancelar_orden(o["element"]):
                        enviar_notificacion(f"❕ {pair} - Orden {order_type} cancelada para reposicionamiento en orden pendiente.")
                    else:
                        logger.error(f"Error al cancelar la orden {order_type} en {pair}.")
                # No se elimina la orden pendiente, se continúa para reintentar reposicionarla.
            
            # Continuar con la lógica de reposicionamiento de la orden pendiente
            referencia = pendiente["reference_fn"]()
            adjustment = Decimal('0.0001') if order_type == "Buy" else Decimal('-0.0001')
            nuevo_precio = redondear_decimal(referencia + adjustment)
            current_price = obtener_precio_actual(pair)
            logger.info(f"[Pendiente] {order_type} en {pair} - Ref: {referencia:.4f}, Propuesto: {nuevo_precio:.4f}, Actual: {current_price:.4f}")
            
            resultado = reposicionar_orden(order_type, referencia, pair, orden_pendiente=pendiente)
            if resultado is True:
                enviar_notificacion(f"☑️ {pair} - Orden {order_type} reposicionada correctamente.")
                remove_pending_order(pendiente)
                driver.refresh()
                time.sleep(2)
            elif resultado == "insufficient_funds":
                logger.info(f"[Pendiente] Orden {order_type} en {pair} no reposicionada por fondos insuficientes.")
                # La orden pendiente se mantiene para reintentar más tarde
            else:
                logger.error(f"Error al reposicionar orden pendiente {order_type} en {pair}. Se reintentará en el próximo ciclo.")
            time.sleep(1)

def obtener_monto_orden_input(order_type: str = "Buy") -> Decimal:
    """
    Lee el valor del input de monto y lo convierte a Decimal.
    Para órdenes Buy se utiliza el input con aria-label="Quote currency" y para Sell con "Base currency".
    Se espera activamente a que el campo tenga un valor distinto de vacío o "0",
    y se aplica una lógica de limpieza que considera distintos formatos numéricos.
    """
    try:
        # Definir el selector según el tipo de orden
        input_label = "Quote currency" if order_type == "Buy" else "Base currency"
        css_selector = f"input[aria-label='{input_label}']"

        # Esperar a que el input sea visible (timeout extendido para Sell)
        input_field = WebDriverWait(driver, 15).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, css_selector))
        )
        driver.execute_script("arguments[0].scrollIntoView(true);", input_field)

        # Obtener el valor usando get_property (más confiable con JS)
        raw_value = (input_field.get_property("value") or "").strip()
        logger.info(f"[Input monto] (Tipo {order_type}) Valor crudo obtenido: '{raw_value}'")
        if raw_value == "" or raw_value == "0":
            return Decimal("0")

        # Eliminar símbolos de moneda y espacios
        for char in ["€", "£", " "]:
            raw_value = raw_value.replace(char, "")

        # Nueva lógica para manejar separadores de miles y decimales
        # Si solo se encuentran comas y no puntos, determinar si la coma es separador de miles.
        if ',' in raw_value and '.' not in raw_value:
            partes = raw_value.split(',')
            # Si todas las partes son dígitos y la última tiene exactamente 3 caracteres,
            # se asume que la coma es separador de miles.
            if all(p.isdigit() for p in partes) and len(partes[-1]) == 3:
                raw_value = ''.join(partes)
            else:
                raw_value = raw_value.replace(',', '.')
        # Si se encuentran tanto comas como puntos, es probable que la coma sea separador de miles.
        elif ',' in raw_value and '.' in raw_value:
            raw_value = raw_value.replace(',', '')
        # Si hay múltiples comas y ningún punto, aplicar la misma heurística
        elif raw_value.count(',') >= 2 and '.' not in raw_value:
            partes = raw_value.split(',')
            # Se asume que todas menos la última son separadores de miles
            raw_value = ''.join(partes[:-1]) + '.' + partes[-1]

        if not raw_value.replace(".", "", 1).isdigit():
            logger.error(f"[Input monto] Valor no numérico tras limpieza: '{raw_value}'")
            return Decimal("0")
        return Decimal(raw_value)
    except Exception as e:
        logger.error(f"Error al obtener el valor del input de monto: {e}")
        return Decimal("0")

def cancelar_todas_ordenes(pair: str) -> bool:
    """
    Intenta cancelar todas las órdenes abiertas para el par indicado.
    Realiza hasta 5 intentos releyendo las órdenes de la página.
    Retorna True si, al final, no quedan órdenes abiertas; False en caso contrario.
    """
    # Asegurarse de estar en la página del par
    target_url = PAIRS_URLS.get(pair)
    if driver.current_url != target_url:
        driver.get(target_url)
        try:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
            )
        except Exception as e:
            logger.error(f"Error esperando elementos en {pair}: {e}")
        time.sleep(2)
        
    max_attempts = 5
    for attempt in range(max_attempts):
        orders = parse_my_open_orders(pair)
        if not orders:
            logger.info(f"Todas las órdenes de {pair} han sido canceladas.")
            return True
        logger.info(f"Intento {attempt+1}/{max_attempts} para cancelar órdenes en {pair}. Se encontraron {len(orders)} órdenes.")
        
        # Agrupar notificaciones por tipo de orden para evitar mensajes repetidos
        canceladas_por_tipo = {}
        for o in orders:
            if cancelar_orden(o["element"]):
                tipo = o['type']
                canceladas_por_tipo[tipo] = canceladas_por_tipo.get(tipo, 0) + 1
                time.sleep(0.3)
            else:
                logger.error(f"Error al cancelar la orden {o['type']} en {pair}")
        # Enviar notificaciones consolidadas
        for tipo, cantidad in canceladas_por_tipo.items():
            enviar_notificacion(f"❕ {pair} - {cantidad} orden(es) {tipo} cancelada(s) por cambio de porcentaje")
        time.sleep(2)  # Esperar a que se actualice la página
    # Releer las órdenes al finalizar los intentos
    orders = parse_my_open_orders(pair)
    if orders:
        logger.error(f"Después de {max_attempts} intentos, aún quedan {len(orders)} órdenes en {pair}.")
        return False
    return True

def convertir_valor(valor_str: str) -> Decimal:
    """
    Convierte una cadena numérica que puede incluir sufijos 'K' (mil) o 'M' (millones) a un Decimal.
    
    Ejemplos:
    - "3.67"     -> 3.67
    - "798.98"   -> 798.98
    - "4.65K"    -> 4650
    - "7.54M"    -> 7540000
    - "1,000.00" -> 1000.00
    """
    try:
        valor_str = valor_str.strip()
        factor = Decimal("1")
        # Detectar y remover sufijos 'K' o 'M'
        if valor_str and valor_str[-1] in "KkMm":
            sufijo = valor_str[-1].upper()
            if sufijo == 'K':
                factor = Decimal("1000")
            elif sufijo == 'M':
                factor = Decimal("1000000")
            valor_str = valor_str[:-1].strip()
        
        # Manejo de separadores de miles y decimales
        if ',' in valor_str and '.' in valor_str:
            if valor_str.index(',') < valor_str.index('.'):
                # Coma como separador de miles
                valor_str = valor_str.replace(',', '')
            else:
                # Punto como separador de miles y coma como decimal
                valor_str = valor_str.replace('.', '').replace(',', '.')
        elif ',' in valor_str:
            partes = valor_str.split(',')
            if len(partes) == 2 and len(partes[1]) <= 2:
                valor_str = valor_str.replace(',', '.')
            else:
                valor_str = valor_str.replace(',', '')

        valor_decimal = Decimal(valor_str)
        return redondear_decimal(valor_decimal * factor)
    except Exception as e:
        logger.error(f"Error al convertir valor '{valor_str}': {e}")
        return Decimal("0")

def obtener_valor_top_buy() -> Decimal:
    """
    Extrae el valor numérico del top buy desde la sección del libro de órdenes.
    Se busca en el contenedor de Buy (igual que en obtener_top_buy) el span
    con la clase que contiene el valor, en lugar del precio.
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Usar el mismo selector del contenedor que en obtener_top_buy()
        buy_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.cssFiH")
            )
        )
        # Usar el mismo selector de filas que en obtener_top_buy()
        rows = buy_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        if rows:
            first_row = rows[0]  # La primera fila contiene el valor top de compra
            # En lugar de buscar el precio, buscamos el valor (normalmente es el último span en la fila)
            # Como no tenemos el selector exacto del valor, tomamos todos los spans y usamos el último
            spans = first_row.find_elements(By.CSS_SELECTOR, "span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0")
            
            # El valor normalmente es el tercer span en la fila (precio, cantidad, valor)
            if spans and len(spans) >= 3:
                raw_value = spans[2].text.strip()
                converted = convertir_valor(raw_value)
                return converted
            
        logger.info("No se encontró un valor de Top Buy válido.")
        return Decimal("0")
    except Exception as e:
        logger.error(f"Error al obtener valor top buy: {e}")
        return Decimal("0")


def obtener_valor_bottom_sell() -> Decimal:
    """
    Extrae el valor numérico del bottom sell desde la sección del libro de órdenes.
    Se busca en el contenedor de Sell (igual que en obtener_bottom_sell) el span
    con la clase que contiene el valor, en lugar del precio.
    """
    try:
        wait = WebDriverWait(driver, 30)
        # Actualizado el selector para el contenedor de Sell
        sell_container = wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.OrderBookList__StyledBox-sc-awjs02-0")
            )
        )
        # Actualizado el selector para las filas
        rows = sell_container.find_elements(By.CSS_SELECTOR, "div.Box-rui__sc-1475jr3-0.Flex-rui__sc-1tnvnxg-0.eFDRzq")

        if not rows:
            logger.info("No hay filas en el contenedor de Sell.")
            return Decimal('0')
            
        last_row = rows[-1]
        # Buscar todos los spans en la fila y tomar el que contiene el valor (normalmente el último)
        spans = last_row.find_elements(By.CSS_SELECTOR, "span.Box-rui__sc-1475jr3-0.Text-rui__sc-1mtagir-0")
        
        if spans and len(spans) >= 3:
            # El valor suele estar en el tercer span (precio, cantidad, valor)
            raw_value = spans[2].text.strip()
            converted = convertir_valor(raw_value)
            return converted
            
        logger.info("No se encontró un valor de Bottom Sell válido.")
        return Decimal("0")
    except Exception as e:
        logger.error(f"Error al obtener valor bottom sell: {e}")
        return Decimal("0")

def detectar_ordenes_ejecutadas(memoria_actual):
    nueva_memoria = {}
    ordenes_por_par = {}  # Cache para evitar múltiples llamadas
    execution_detected = False

    try:
        # Recopilar órdenes abiertas actuales para cada par
        for pair in PAIRS_URLS.keys():
            target_url = PAIRS_URLS.get(pair)
            if driver.current_url != target_url:
                driver.get(target_url)
                try:
                    WebDriverWait(driver, 30).until(
                        EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
                    )
                    time.sleep(1)
                except Exception as e:
                    logger.error(f"Error esperando elementos en {pair}: {e}")
                    continue

            open_orders = parse_my_open_orders(pair)
            ordenes_por_par[pair] = open_orders
            for order in open_orders:
                key = (pair, order["type"])
                nueva_memoria[key] = order

        pending_keys = {(p["pair"], p["order_type"]) for p in ordenes_pendientes if p.get("status") != "insufficient_funds"}
        trades = obtener_ultimas_transacciones()

        for key, order in memoria_actual.items():
            if key not in nueva_memoria and key not in pending_keys:
                try:
                    found = False
                    for trade in trades:
                        order_pair = key[0].replace(" ", "").upper()
                        trade_pair = trade["pair"].replace(" ", "").upper()
                        order_type = order["type"].strip()
                        trade_type = trade["type"].strip()
                        order_price = redondear_decimal(Decimal(str(order["price"])))
                        trade_price = redondear_decimal(Decimal(str(trade["price"])))
                        order_value = redondear_decimal(Decimal(str(order["eur_value"])))
                        trade_value = redondear_decimal(Decimal(str(trade["value"])))

                        # Definir tolerancias
                        price_tolerance = Decimal("0.0001")
                        value_tolerance = Decimal("1.0")  # Aumentada a 0.1 EUR

                        # Logging detallado para depuración
                        logger.info(f"Comparando orden: {order_pair}, {order_type}, price={order_price}, value={order_value}")
                        logger.info(f"Con trade: {trade_pair}, {trade_type}, price={trade_price}, value={trade_value}")
                        logger.info(f"Diferencias: price_diff={abs(order_price - trade_price)}, value_diff={abs(order_value - trade_value)}")

                        if (order_pair == trade_pair and
                            order_type == trade_type and
                            abs(order_price - trade_price) <= price_tolerance and
                            abs(order_value - trade_value) <= value_tolerance):
                            found = True
                            logger.info(f"Coincidencia encontrada para {key}")
                            break

                    if found:
                        ganancia_actual = calcular_ganancia_portfolio(driver)
                        mensaje = (
                            f"✅ {key[0]} - Orden {order['type']} ejecutada completamente a {order['price']:.4f}\n"
                            f"Cantidad ejecutada: {order['eur_value']:.2f} EUR\n"
                            f"Ganancia actual: {ganancia_actual:.2f} EUR"
                        )
                        enviar_notificacion_sec(mensaje)
                        logger.info(f"Detectada ejecución completa: {mensaje}")

                        pair = key[0]
                        target_url = PAIRS_URLS.get(pair)
                        if driver.current_url != target_url:
                            driver.get(target_url)
                            WebDriverWait(driver, 30).until(
                                EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
                            )
                            time.sleep(1)

                        opposite_type = "Sell" if order["type"] == "Buy" else "Buy"
                        current_orders = ordenes_por_par.get(pair, parse_my_open_orders(pair))
                        for opp_order in current_orders:
                            if opp_order["type"] == opposite_type:
                                if cancelar_orden(opp_order["element"]):
                                    enviar_notificacion(f"❕ {pair} - Orden {opposite_type} cancelada tras ejecución completa.")
                                else:
                                    logger.error(f"Error al cancelar la orden opuesta en {pair}.")

                        if opposite_type == "Buy":
                            agregar_orden_pendiente("Buy", pair, obtener_top_buy)
                        else:
                            agregar_orden_pendiente("Sell", pair, obtener_bottom_sell)
                        
                        execution_detected = True

                except Exception as e:
                    logger.error(f"Error procesando ejecución de orden {key}: {e}")

        if execution_detected:
            for pendiente in ordenes_pendientes:
                if pendiente.get("status") == "insufficient_funds":
                    pendiente["status"] = "pending"
                    logger.info(f"[Pendiente] Liberando flag de fondos insuficientes para {pendiente['pair']} (ID: {pendiente['id']}).")

        return nueva_memoria
    except Exception as e:
        logger.error(f"Error general en detectar_ordenes_ejecutadas: {e}")
        return memoria_actual
    

def verificar_ordenes_incompletas():
    """
    Verifica que existan exactamente 4 órdenes en total (2 por par: una Buy y una Sell).
    Si al iniciar el bot o durante algún ciclo se detecta que falta alguna (en abiertas y/o pendientes),
    se añade la que falta a pendientes (evitando duplicidad).
    """
    # Definir el conjunto esperado de órdenes: (par, tipo)
    expected_orders = set()
    for pair in PAIRS_URLS.keys():
        expected_orders.add((pair, "Buy"))
        expected_orders.add((pair, "Sell"))
    
    # --------------------------------------------
    # Cancelar duplicados en caliente antes de contar
    # --------------------------------------------
    for pair in PAIRS_URLS.keys():
        for order_type in ["Buy", "Sell"]:
            dups = [o for o in parse_my_open_orders(pair) if o["type"] == order_type]
            if len(dups) > 1:
                logger.warning(f"Se detectan {len(dups)} duplicados {order_type} en {pair}. Cancelando excedentes.")
                # Mantener la más antigua
                for dup in dups[1:]:
                    cancelar_orden(dup["element"])
    time.sleep(1)  # breve espera para que la UI se actualice

    # --------------------------------------------
    # Recoger de nuevo las órdenes abiertas tras la limpieza,
    # navegando a cada par para que parse_my_open_orders() lea la tabla correcta.
    # --------------------------------------------
    open_orders_set = set()
    for pair in PAIRS_URLS.keys():
        target_url = PAIRS_URLS.get(pair)
        if driver.current_url != target_url:
            driver.get(target_url)
            try:
                WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
                )
                time.sleep(1)
            except Exception as e:
                logger.error(f"[Verificación] Error cargando página de {pair}: {e}")
                continue

        orders = parse_my_open_orders(pair)
        for order in orders:
            open_orders_set.add((pair, order["type"]))

    # Obtener órdenes pendientes registradas en la variable global
    pending_orders_set = set()
    for pending in ordenes_pendientes:
        pending_orders_set.add((pending["pair"], pending["order_type"]))
    
    total_orders = open_orders_set.union(pending_orders_set)
    logger.info(f"[Verificación] Órdenes existentes (abiertas+pendientes): {total_orders}")

    # Si hay menos de 4 órdenes en total, se añaden las que faltan a pendientes
    if len(total_orders) < 4:
        for expected in expected_orders:
            if expected not in total_orders:
                # Para determinar la función de referencia según el tipo de orden
                if expected[1] == "Buy":
                    ref_fn = obtener_top_buy
                else:  # Sell
                    ref_fn = obtener_bottom_sell
                # Antes de agregar, asegurarse de que no esté ya en pendientes
                if (expected[0], expected[1]) not in pending_orders_set:
                    agregar_orden_pendiente(expected[1], expected[0], ref_fn)
                    logger.info(f"[Verificación] Se agregó orden pendiente {expected[1]} para {expected[0]} por falta de orden.")

def limpiar_valor(texto: str) -> str:
    """
    Limpia y normaliza una cadena numérica eliminando símbolos y manejando formatos.
    Devuelve una cadena lista para convertirse a Decimal o una cadena vacía si no es válida.
    """
    if not texto:
        return ""
    # Eliminar símbolos de moneda y espacios
    texto = texto.strip().replace("€", "").replace("£", "").replace(" ", "")
    # Reemplazar coma por punto si parece ser un separador decimal
    if "," in texto and "." in texto:
        # Si hay ambos, asumir que la coma es separador de miles
        texto = texto.replace(",", "")
    elif "," in texto:
        partes = texto.split(",")
        if len(partes) == 2 and len(partes[1]) <= 2:  # Ejemplo: "12,34"
            texto = texto.replace(",", ".")
        else:
            texto = texto.replace(",", "")  # Ejemplo: "1,234" -> "1234"
    # Verificar si el resultado es numérico (permite un solo punto decimal)
    if texto.replace(".", "", 1).replace("-", "", 1).isdigit():
        return texto
    return ""

def obtener_ultimas_transacciones():
    trades = []
    try:
        # Guardar la URL actual para volver después
        current_url = driver.current_url

        # Hacer click en el botón "Trades"
        trades_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[text()='Trades']"))
        )
        trades_button.click()
        time.sleep(2)  # Esperar a que se cargue la tabla de Trades

        # Ubicar la tabla de trades
        table_wrapper = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@data-rui-part='table-scroll-wrapper']"))
        )
        rowgroup = table_wrapper.find_element(By.XPATH, ".//div[@role='rowgroup']")
        rows = rowgroup.find_elements(By.XPATH, ".//div[@role='row']")

        for row in rows[:10]:  # Revisar hasta 10 transacciones
            try:
                # Extraer el par
                cell_pair = row.find_element(By.XPATH, ".//div[@aria-colindex='1']")
                pair_text = cell_pair.text.strip()

                # Extraer el tipo de orden
                cell_type = row.find_element(By.XPATH, ".//div[@aria-colindex='3']")
                type_text = cell_type.text.strip()

                # En la nueva UI, Price está una columna antes de Value
                cell_price = row.find_element(By.XPATH, ".//div[@aria-colindex='5']")
                raw_price = cell_price.text.strip()
                cleaned_price = limpiar_valor(raw_price)
                if cleaned_price:
                    try:
                        price = redondear_decimal(Decimal(cleaned_price))
                    except decimal.ConversionSyntax as e:
                        logger.error(f"Error convirtiendo precio '{cleaned_price}': {e}")
                        price = Decimal("0")
                else:
                    logger.warning(f"Precio no válido o vacío: '{raw_price}'")
                    price = Decimal("0")

                cell_value = row.find_element(By.XPATH, ".//div[@aria-colindex='6']")
                raw_value = cell_value.text.strip()
                cleaned_value = limpiar_valor(raw_value)
                if cleaned_value:
                    try:
                        value = redondear_decimal(Decimal(cleaned_value))
                    except decimal.ConversionSyntax as e:
                        logger.error(f"Error convirtiendo valor '{cleaned_value}': {e}")
                        value = Decimal("0")
                else:
                    logger.warning(f"Valor no válido o vacío: '{raw_value}'")
                    value = Decimal("0")

                trades.append({
                    "pair": pair_text,
                    "type": type_text,
                    "price": price,
                    "value": value
                })
            except Exception as inner_e:
                logger.error(f"Error al parsear una transacción: {inner_e}")
                continue

        # Volver a la pestaña 'Orders'/'Open orders'
        ensure_orders_tab()
        time.sleep(2)
        return trades
    except Exception as e:
        logger.error(f"Error al obtener transacciones: {e}")
        return []

# ------------------------------------------------
# MODIFICACIÓN EN LA FUNCIÓN DE MONITOREO
# ------------------------------------------------
def monitorear():
    global driver, memoria_ordenes  # Añadido memoria_ordenes a las globales
    state = {
        'prev_order_count': {},
        'sent_alerts': {},
        'previous_percentages': {},
        'sent_percentage_alerts': {}
    }
    # Inicializar el estado para cada par configurado
    for pair in PAIRS_URLS.keys():
        state['prev_order_count'][pair] = None
        state['sent_alerts'][pair] = set()
        state['previous_percentages'][pair] = {}
        state['sent_percentage_alerts'][pair] = set()

    # Inicializar diccionario para almacenar las órdenes del ciclo anterior
    prev_orders_by_pair = {}

    while True:
        try:
            # Verificar si faltan órdenes y agregarlas a pendientes en caso
            verificar_ordenes_incompletas()
            acciones_en_ciclo = False
            evento_recibido = False  # Variable para detectar eventos relevantes (ejecución completa o cambio de porcentaje)
            # Diccionario para almacenar las órdenes actuales (clave: (tipo, id)) por par
            current_orders_by_pair = {}

            # Obtener la lista de pares activos (con órdenes abiertas)
            pares_activos = parse_all_open_orders(driver)

            for pair in pares_activos:
                if pair not in PAIRS_URLS:
                    continue

                url_pair = PAIRS_URLS[pair]
                # Navegar o refrescar la página según corresponda
                if driver.current_url != url_pair:
                    driver.get(url_pair)
                else:
                    driver.refresh()
                WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located((By.XPATH, '//div[@role="row"]'))
                )

                # Actualizar el precio inverso y escribirlo en el archivo
                inversa = obtener_precio_actual(pair)
                actualizar_inverse_price(pair, inversa)

                # Obtener precios relevantes para el par
                top_buy = obtener_top_buy()
                second_top_buy = obtener_second_top_buy()
                bottom_sell = obtener_bottom_sell()
                second_bottom_sell = obtener_second_bottom_sell()

                # Parsear las órdenes abiertas para el par
                orders = parse_my_open_orders(pair)
                current_order_count = len(orders)
                # Almacenar la firma de las órdenes actuales para este par (tipo, id)
                current_orders_by_pair[pair] = {(order["type"], order["id"]): order for order in orders}

                prev_count = state['prev_order_count'][pair]
                if prev_count is not None and current_order_count < prev_count:
                    alerta = f"⚠️ {pair} - Bajan órdenes de {prev_count} a {current_order_count}"
                    if alerta not in state['sent_alerts'][pair]:
                        enviar_notificacion(alerta)
                        state['sent_alerts'][pair].add(alerta)
                state['prev_order_count'][pair] = current_order_count

                # Detectar cambios de porcentaje en las órdenes
                percentage_change_detected = False
                changed_order = None
                for order in orders:
                    tipo = order['type']
                    orden_id = f"{tipo}-{pair}"
                    porcentaje = order['percentage']
                    if orden_id not in state['previous_percentages'][pair]:
                        state['previous_percentages'][pair][orden_id] = porcentaje
                    else:
                        prev_percent = state['previous_percentages'][pair][orden_id]
                        if porcentaje > prev_percent + 5:
                            percentage_change_detected = True
                            changed_order = order
                            break
                        else:
                            state['previous_percentages'][pair][orden_id] = porcentaje

                if percentage_change_detected:
                    tipo = changed_order['type']
                    precio = changed_order['price']
                    prev_percent = state['previous_percentages'][pair][f"{tipo}-{pair}"]
                    nuevo_percent = changed_order['percentage']
                    diff = nuevo_percent - prev_percent
                    euros_executed = (diff / 100.0) * changed_order['eur_value']
                    ganancia_actual = calcular_ganancia_portfolio(driver)
                    alerta = (f"✅ {pair} - {tipo} @ {precio:.4f}: "
                              f"(Δ +{diff:.2f}%) → {euros_executed:.2f} EUR | 💰 Ganancia actual: {ganancia_actual:.2f} EUR")
                    alert_id = f"{pair}-{tipo}-{prev_percent:.2f}->{nuevo_percent:.2f}"
                    if alert_id not in state['sent_percentage_alerts'][pair]:
                        enviar_notificacion_sec(alerta)
                        state['sent_percentage_alerts'][pair].add(alert_id)
                    else:
                        logger.info(f"Alerta de porcentaje ya enviada: {alert_id}")

                    # Cancelar todas las órdenes abiertas y agregar pendientes para reposicionarlas
                    if not cancelar_todas_ordenes(pair):
                        logger.error(f"No se pudieron cancelar todas las órdenes en {pair}.")
                    nuevo_precio_buy = redondear_decimal(top_buy + Decimal("0.0001"))
                    nuevo_precio_sell = redondear_decimal(bottom_sell - Decimal("0.0001"))
                    agregar_orden_pendiente("Buy", pair, obtener_top_buy, nuevo_precio_buy)
                    agregar_orden_pendiente("Sell", pair, obtener_bottom_sell, nuevo_precio_sell)
                    for order in orders:
                        tipo = order['type']
                        orden_id = f"{tipo}-{pair}"
                        state['previous_percentages'][pair][orden_id] = order['percentage']
                    evento_recibido = True  # Se detectó un evento relevante
                    acciones_en_ciclo = True
                    continue

                # Procesar cada orden individualmente
                for order in orders:
                    tipo = order['type']
                    precio = order['price']  # Precio de la orden (Decimal)
                    current_price = obtener_precio_actual(pair)

                    # CASO 1: Cancelación forzada por precio actual (independiente de reposicionamiento)
                    if tipo == "Buy":
                        if current_price == precio:
                            if cancelar_orden(order['element']):
                                orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                enviar_notificacion(f"❕ {pair} - Orden Buy cancelada @ {precio:.4f} (Precio actual igual)")
                                driver.refresh()
                                nuevo_precio = redondear_decimal(top_buy + Decimal("0.0001"))
                                agregar_orden_pendiente("Buy", pair, obtener_top_buy, nuevo_precio)
                                acciones_en_ciclo = True
                            else:
                                logger.error(f"Error al cancelar la orden Buy en {pair} (Precio actual igual)")
                            continue

                    elif tipo == "Sell":
                        if current_price >= (precio + Decimal('0.0005')):
                            if cancelar_orden(order['element']):
                                orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                enviar_notificacion(f"❕ {pair} - Orden Sell cancelada @ {precio:.4f} (Precio actual superior en >=0.0005)")
                                driver.refresh()
                                nuevo_precio = redondear_decimal(bottom_sell - Decimal("0.0001"))
                                agregar_orden_pendiente("Sell", pair, obtener_bottom_sell, nuevo_precio)
                                evento_recibido = True
                                acciones_en_ciclo = True
                            else:
                                logger.error(f"Error al cancelar la orden Sell en {pair} (Precio actual superior en >=0.0005)")
                            continue

                    # CASO 2: Evaluar reposicionamiento programable (cancelar solo si el precio actual lo permite)
                    if tipo == "Buy":
                        competitor_price = top_buy
                        competitor_value = obtener_valor_top_buy()
                        diferencia = competitor_price - precio
                        reposition = False
                        nuevo_precio = None
                        if diferencia > Decimal("0"):
                            increments = (diferencia / Decimal("0.0001")).to_integral_value(rounding=ROUND_DOWN)
                            threshold = increments * Decimal("500")
                            if competitor_value > threshold:
                                reposition = True
                                nuevo_precio = redondear_decimal(competitor_price + Decimal("0.0001"))
                                if current_price > nuevo_precio:
                                    if cancelar_orden(order['element']):
                                        orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                        enviar_notificacion(f"☑️ {pair} - Orden Buy cancelada y reposicionada a {nuevo_precio:.4f} (Competidor: {competitor_price:.4f}, Valor: {competitor_value})")
                                        driver.refresh()
                                        agregar_orden_pendiente("Buy", pair, obtener_top_buy, nuevo_precio, origen="caso_2")
                                        acciones_en_ciclo = True
                                    else:
                                        logger.error(f"Error al cancelar la orden Buy en {pair} (competidor encima).")
                                    continue
                            else:
                                if not reposition:
                                    continue  # No se reposiciona si no se cumple la condición de valor

                        # Alternativa usando second_top_buy
                        if second_top_buy > 0 and (top_buy - second_top_buy) >= Decimal('0.0002'):
                            alt_nuevo_precio = redondear_decimal(second_top_buy + Decimal('0.0001'))
                            if current_price > alt_nuevo_precio:
                                if cancelar_orden(order['element']):
                                    orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                    enviar_notificacion(f"☑️ {pair} - Orden Buy cancelada y reposicionada por encima del second top a {alt_nuevo_precio:.4f}")
                                    driver.refresh()
                                    agregar_orden_pendiente("Buy", pair, obtener_top_buy, alt_nuevo_precio, origen="caso_2")
                                    acciones_en_ciclo = True
                                else:
                                    logger.error(f"Error al cancelar la orden Buy en {pair} (caso second_top_buy).")
                                continue
                            else:
                                continue

                    elif tipo == "Sell":
                        competitor_price = bottom_sell
                        competitor_value = obtener_valor_bottom_sell()
                        diferencia = precio - competitor_price
                        reposition = False
                        nuevo_precio = None
                        if diferencia > Decimal("0"):
                            increments = (diferencia / Decimal("0.0001")).to_integral_value(rounding=ROUND_DOWN)
                            threshold = increments * Decimal("500")
                            if competitor_value > threshold:
                                reposition = True
                                nuevo_precio = redondear_decimal(competitor_price - Decimal("0.0001"))
                                if current_price < (nuevo_precio + Decimal("0.0005")):
                                    if cancelar_orden(order['element']):
                                        orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                        enviar_notificacion(f"☑️ {pair} - Orden Sell cancelada y reposicionada a {nuevo_precio:.4f} (Competidor: {competitor_price:.4f}, Valor: {competitor_value})")
                                        driver.refresh()
                                        agregar_orden_pendiente("Sell", pair, obtener_bottom_sell, nuevo_precio, origen="caso_2")
                                        acciones_en_ciclo = True
                                    else:
                                        logger.error(f"Error al cancelar la orden Sell en {pair} (competidor debajo).")
                                    continue
                            else:
                                if not reposition:
                                    continue  # No se reposiciona si no se cumple la condición de valor

                        # Alternativa usando second_bottom_sell
                        if second_bottom_sell > 0 and (second_bottom_sell - bottom_sell) >= Decimal('0.0002'):
                            alt_nuevo_precio = redondear_decimal(second_bottom_sell - Decimal('0.0001'))
                            if current_price < (alt_nuevo_precio + Decimal('0.0005')):
                                if cancelar_orden(order['element']):
                                    orders_cancelled_for_repositioning.add((pair, order["type"], order["id"]))
                                    enviar_notificacion(f"☑️ {pair} - Orden Sell cancelada y reposicionada por debajo del second bottom a {alt_nuevo_precio:.4f}")
                                    driver.refresh()
                                    agregar_orden_pendiente("Sell", pair, obtener_bottom_sell, alt_nuevo_precio, origen="caso_2")
                                    acciones_en_ciclo = True
                                else:
                                    logger.error(f"Error al cancelar la orden Sell en {pair} (caso second_bottom_sell).")
                                continue
                            else:
                                logger.info(f"No se cancela la orden Sell en {pair} porque current_price ({current_price:.4f}) no permite reposicionar usando el segundo bottom ({alt_nuevo_precio:.4f}).")
                                continue

                    # Alertas de cercanía de precio
                    if tipo == "Sell":
                        diff = abs(precio - current_price)
                        if diff <= Decimal('0.0002'):
                            alerta = f"⚠️ {pair} - Sell @ {precio:.4f} cerca del precio actual {current_price:.4f} (Diferencia: {diff:.4f})"
                            if alerta not in state['sent_alerts'][pair]:
                                enviar_notificacion(alerta)
                                state['sent_alerts'][pair].add(alerta)
                    elif tipo == "Buy":
                        diff = abs(current_price - precio)
                        if diff <= Decimal('0.0004'):
                            alerta = f"⚠️ {pair} - Buy @ {precio:.4f} cerca del precio actual {current_price:.4f} (Diferencia: {diff:.4f})"
                            if alerta not in state['sent_alerts'][pair]:
                                enviar_notificacion(alerta)
                                state['sent_alerts'][pair].add(alerta)

            # Al finalizar el ciclo, se procesan también las órdenes pendientes para evitar falsos positivos
            procesar_ordenes_pendientes()

            if not acciones_en_ciclo:
                memoria_ordenes = detectar_ordenes_ejecutadas(memoria_ordenes)
            else:
                logger.info("Acciones en ciclo activas; se omite la detección de órdenes ejecutadas para evitar falsos positivos.")

            # Liberar flag de 'insufficient_funds' en órdenes pendientes si se detectó algún evento relevante
            if evento_recibido:
                for pendiente in ordenes_pendientes:
                    if pendiente.get("status") == "insufficient_funds":
                        pendiente["status"] = "pending"
                        logger.info(f"[Pendiente] Liberando flag de fondos insuficientes para {pendiente['pair']} (ID: {pendiente['id']}).")

            time.sleep(0)

        except InvalidSessionIdException as e:
            logger.error("Invalid session id detectado. Reiniciando el driver...")
            try:
                driver.quit()
            except Exception:
                pass
            driver = iniciar_driver(URL_INICIAL)
        except Exception as e:
            logger.error(f"Error en monitorear: {e}")
            time.sleep(3)

if __name__ == "__main__":
    try:
        monitorear()
    except KeyboardInterrupt:
        logger.info("Bot detenido.")